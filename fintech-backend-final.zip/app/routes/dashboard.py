
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func, case
from app.database import get_db
from app.models.ledger import LedgerEntry

router = APIRouter(prefix="/dashboard")

@router.get("/summary")
def summary(db: Session = Depends(get_db)):
    r = db.query(
        func.sum(case((LedgerEntry.entry_type=='credit', LedgerEntry.amount), else_=0)),
        func.sum(case((LedgerEntry.entry_type=='debit', LedgerEntry.amount), else_=0))
    ).one()
    inc = r[0] or 0
    exp = r[1] or 0
    return {"income":inc,"expense":exp,"balance":inc-exp}
