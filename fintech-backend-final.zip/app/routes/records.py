
from fastapi import APIRouter, Depends, Header
from sqlalchemy.orm import Session
from app.database import get_db
from app.services.transaction_service import create_transaction

router = APIRouter(prefix="/records")

@router.post("/")
def create(data: dict, db: Session = Depends(get_db), x_idempotency_key: str = Header(...)):
    return create_transaction(db, 1, data, x_idempotency_key)
