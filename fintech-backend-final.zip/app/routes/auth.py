
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.user import User
from app.core.security import hash_password, verify_password, create_token

router = APIRouter(prefix="/auth")

@router.post("/register")
def register(data: dict, db: Session = Depends(get_db)):
    u = User(email=data["email"], password=hash_password(data["password"]), role=data.get("role","viewer"))
    db.add(u)
    db.commit()
    return {"msg":"created"}

@router.post("/login")
def login(data: dict, db: Session = Depends(get_db)):
    u = db.query(User).filter_by(email=data["email"]).first()
    if not u or not verify_password(data["password"], u.password):
        return {"error":"invalid"}
    return {"token": create_token({"sub":u.email})}
