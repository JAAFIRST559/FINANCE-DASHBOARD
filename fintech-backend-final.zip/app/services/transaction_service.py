
import uuid
from sqlalchemy.orm import Session
from app.models.ledger import LedgerEntry
from app.models.idempotency import IdempotencyKey

def create_transaction(db: Session, user_id, data, key):
    if db.query(IdempotencyKey).filter_by(key=key).first():
        return {"message": "duplicate prevented"}

    tx = str(uuid.uuid4())
    with db.begin():
        db.add(LedgerEntry(user_id=user_id, transaction_id=tx, entry_type="debit", account="cash", amount=data.amount))
        db.add(LedgerEntry(user_id=user_id, transaction_id=tx, entry_type="credit", account=data.category, amount=data.amount))
        db.add(IdempotencyKey(key=key, user_id=user_id))
    return {"transaction_id": tx}
