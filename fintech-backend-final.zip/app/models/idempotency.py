
from sqlalchemy import Column, String, Integer
from app.database import Base

class IdempotencyKey(Base):
    __tablename__ = "idempotency_keys"
    key = Column(String, primary_key=True)
    user_id = Column(Integer)
