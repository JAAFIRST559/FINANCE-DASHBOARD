
from sqlalchemy import Column, Integer, String, Numeric, DateTime, ForeignKey
from sqlalchemy.sql import func
from app.database import Base

class LedgerEntry(Base):
    __tablename__ = "ledger_entries"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    transaction_id = Column(String, index=True)
    entry_type = Column(String)
    account = Column(String)
    amount = Column(Numeric(12,2))
    created_at = Column(DateTime, server_default=func.now())
